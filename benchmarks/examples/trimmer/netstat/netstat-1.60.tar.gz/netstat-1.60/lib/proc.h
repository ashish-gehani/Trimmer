

/* Generate a suitable scanf format for a column title line */
char *proc_gen_fmt(char *name, int more, FILE * fh,...);
int   proc_guess_fmt(char *name, FILE* fh,...);
